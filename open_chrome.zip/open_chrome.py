import time
import random
import sys
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def human_type(element, text: str, min_delay: float = 0.08, max_delay: float = 0.25):
    """মানুষের মতো টাইপিং স্পিড সিমুলেট করার ফাংশন"""
    for char in text:
        element.send_keys(char)
        time.sleep(random.uniform(min_delay, max_delay))

def human_scroll(driver, scroll_steps: int = 2):
    """মানুষের মতো পেজ স্ক্রোল করার ফাংশন"""
    for _ in range(scroll_steps):
        scroll_amount = random.randint(100, 300)
        driver.execute_script(f"window.scrollBy(0, {scroll_amount});")
        time.sleep(random.uniform(0.8, 1.5))

def open_undetected_browser(url: str, password: str = "!@#$%Abolt!@#$%Abolt"):
    options = uc.ChromeOptions()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-popup-blocking")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    
    print("[+] Launching Undetected Chrome Driver...")
    
    if sys.platform == "win32":
        driver = uc.Chrome(options=options, version_main=152)
    else:
        driver = uc.Chrome(options=options)
    
    try:
        print(f"[+] Visiting: {url}")
        driver.get(url)
        
        # পেজ লোড ও রেন্ডারিংয়ের জন্য সময় দেওয়া
        time.sleep(random.uniform(4.0, 7.0))
        
        print(f"[+] Current Page Title: {driver.title}")
        print(f"[+] Current URL: {driver.current_url}")
        
        # GitHub সাইনআপের পাসওয়ার্ড ফিল্ড বা ইনপুট খোঁজা (একাধিক সেলেক্টর ট্রাই করা)
        wait = WebDriverWait(driver, 20)
        print("[+] Locating password input...")
        
        selectors = [
            (By.ID, "password"),
            (By.NAME, "password"),
            (By.XPATH, "//input[@type='password']"),
            (By.CSS_SELECTOR, "input[autocomplete='new-password']"),
            (By.CSS_SELECTOR, "input[autocomplete='current-password']")
        ]
        
        password_field = None
        for by, val in selectors:
            try:
                password_field = wait.until(EC.element_to_be_clickable((by, val)))
                if password_field:
                    print(f"[+] Found password field using {by} = {val}")
                    break
            except Exception:
                continue
                
        if password_field:
            time.sleep(random.uniform(1.0, 2.0))
            password_field.click()
            time.sleep(random.uniform(0.5, 1.0))
            print(f"[+] Typing password with human speed...")
            human_type(password_field, password)
            print("[+] Password typed successfully!")
        else:
            print("[!] Password field not found immediately, staying open for inspection.")
        
        human_scroll(driver, scroll_steps=3)
        
        print("\n[+] Keeping browser live for viewing (15 minutes)...")
        # লাইভ GUI দেখতে পাওয়ার জন্য ১৫ মিনিট ব্রাউজার ওপেন রাখা
        for remaining in range(900, 0, -10):
            print(f"[+] Browser active... {remaining}s remaining")
            time.sleep(10)
            
    except Exception as e:
        print(f"[!] Error: {e}")
        time.sleep(60)
    finally:
        try:
            driver.quit()
        except Exception:
            pass

if __name__ == "__main__":
    target_url = "https://github.com/signup?source=form-home-signup&user_email=tgfar@googlegroups.com"
    target_password = "!@#$%Abolt!@#$%Abolt"
    open_undetected_browser(target_url, target_password)
