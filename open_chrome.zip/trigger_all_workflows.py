import subprocess
import time
import sys

def run_workflow_for_all_repos(start_id: int = 1, end_id: int = 20, delay_seconds: int = 60):
    """
    ghspro9 অ্যাকাউন্টের selenium-runner-1 থেকে selenium-runner-20 রিপোজিটরির
    GitHub Actions workflow একের পর এক ট্রিগার করবে এবং মাঝে ১ মিনিট (৬০ সেকেন্ড) ডিলে দেবে।
    """
    total = end_id - start_id + 1
    print(f"==================================================================")
    print(f"[*] Starting workflow triggers for {total} repositories (ghspro9/selenium-runner-{start_id}..{end_id})")
    print(f"[*] Delay between triggers: {delay_seconds} seconds (1 minute)")
    print(f"==================================================================\n")

    for i in range(start_id, end_id + 1):
        repo = f"ghspro9/selenium-runner-{i}"
        print(f"[{i}/{end_id}] 🚀 Triggering workflow on {repo}...")

        # gh workflow run main.yml --repo <repo> কমান্ড চালানো
        cmd = ["gh", "workflow", "run", "main.yml", "--repo", repo]
        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode == 0:
            print(f"    ✅ Workflow successfully triggered for {repo}")
        else:
            print(f"    ❌ Failed to trigger {repo}. Error: {result.stderr.strip()}")

        # শেষ রিপোজিটরির পর অপ্রয়োজনীয় ওয়েট না করা
        if i < end_id:
            print(f"    ⏳ Waiting {delay_seconds} seconds before triggering the next repository...")
            for remaining in range(delay_seconds, 0, -10):
                print(f"       Remaining: {remaining}s...", end="\r", flush=True)
                time.sleep(min(10, remaining))
            print()

    print("\n==================================================================")
    print("[*] All 20 workflows have been triggered successfully!")
    print("==================================================================")

if __name__ == "__main__":
    try:
        run_workflow_for_all_repos(start_id=1, end_id=20, delay_seconds=60)
    except KeyboardInterrupt:
        print("\n[!] Process stopped by user.")
        sys.exit(0)
